## Set up session:

# OpenCV:
import numpy as np
import cv2

if __name__ == '__main__':
    # Load and format image:
    image = cv2.cvtColor(
        cv2.imread('planes.png'),
        cv2.COLOR_BGR2GRAY
    )

    # Find contours:
    _, contours, hierarchy = cv2.findContours(
        # The method will modify the input image:
        image = image.copy(),
        mode = cv2.RETR_EXTERNAL,
        method = cv2.CHAIN_APPROX_SIMPLE
    )

    for index, contour in enumerate(contours):
        (x, y, w, h) = cv2.boundingRect(contour)

        ROI = image[y:y+h, x:x+w]
        shape_features = cv2.HuMoments(cv2.moments(ROI)).flatten()

        print "[ROI {}]: {}".format(index + 1, shape_features)

        cv2.imshow("ROI", ROI)
        cv2.waitKey(0)
