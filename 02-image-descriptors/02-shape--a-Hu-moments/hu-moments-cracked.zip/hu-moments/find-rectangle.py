## Set up session:
# 1. File system:
from os import listdir
from os.path import join
# 2. OpenCV:
import numpy as np
import cv2
# 3. Outlier detection:
from sklearn.metrics.pairwise import pairwise_distances
# 4. Visualization:
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

## Config:
INPUT = 'quiz'

if __name__ == '__main__':
    image_filenames = []
    image_features = []

    for image_filename in listdir(INPUT):
        # Add filename record:
        image_filenames.append(image_filename)

        # Load and binarize--Hard Thresholding:
        _, image_binary = cv2.threshold(
            cv2.cvtColor(
                cv2.imread(join(INPUT, image_filename)),
                cv2.COLOR_BGR2GRAY
            ),
            2,
            255,
            cv2.THRESH_BINARY
        )

        # Find max contour and extract ROI:
        contours = cv2.findContours(
            image_binary.copy(),
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )[1]
        (x, y, w, h) = cv2.boundingRect(
            max(contours, key=cv2.contourArea)
        )
        # Rescale to make the extracted feature scale invariant:
        ROI = cv2.resize(
            image_binary[y:y+h, x:x+w],
            (50, 50)
        )

        # Extract Hu moments:
        image_features.append(
            cv2.HuMoments(
                cv2.moments(ROI)
            ).flatten()
        )

    # Detect the outlier:
    X = np.array(image_features)

    print X

    exit(0)

    # Visualize:
    pca = PCA(
        n_components = 2,
        whiten = True
    )
    X_reduced = pca.fit_transform(X)
    plt.figure()
    plt.scatter(
        X_reduced[:, 0], X_reduced[:, 1]
    )
    plt.grid()
    plt.show()

    D = pairwise_distances(
        X,
        n_jobs = 4
    ).sum(axis = 1)

    outlier_index = np.argmax(D)

    cv2.imshow(
        "Outlier",
        cv2.imread(join(INPUT, image_filenames[outlier_index]))
    )
    cv2.waitKey(0)
