## Set up session:
import argparse
import glob
from os.path import join
import re

import numpy as np
import cv2
import mahotas

from sklearn.preprocessing import LabelEncoder, Normalizer
# Cross validation:
from sklearn.model_selection import StratifiedShuffleSplit
# Classifier:
from sklearn.svm import LinearSVC
# Evaluation metric:
from sklearn.metrics import accuracy_score
from sklearn.metrics import make_scorer
from sklearn.metrics import classification_report
# Hyperparameter tuning:
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline


if __name__ == '__main__':
    # Command-line arguments:
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--training", required=True, help="Path to texture training dataset.")
    parser.add_argument("-t", "--testing", required=True, help="Path to testing dataset.")
    # Format command-line arguments as key-value pairs:
    args = vars(parser.parse_args())

    def extract_dataset(dataset_dir):
        """ Extract features and labels from given dataset

        """
        features = []
        textures = []
        texture_parser = re.compile(r"\w+/([\w-]+)_\d+\.png")
        for image_file in glob.glob(join(dataset_dir, "*.png")):
            # Parse texture:
            textures.append(texture_parser.match(image_file).group(1))
            # Extract features:
            features.append(
                mahotas.features.haralick(
                    cv2.cvtColor(
                        cv2.imread(image_file),
                        cv2.COLOR_BGR2GRAY
                    )
                ).mean(axis = 0)
            )

        return (features, textures)

    (features_train, labels_train) = extract_dataset(args["training"])
    (features_test, labels_test) = extract_dataset(args["testing"])

    label_encoder = LabelEncoder()

    X_train = np.array(features_train)
    y_train = label_encoder.fit_transform(labels_train)
    X_test = np.array(features_test)
    y_test = label_encoder.transform(labels_test)

    # Create cross-validation sets from the training data
    cv_sets = StratifiedShuffleSplit(n_splits = 5, test_size = 0.25, random_state = 42).split(X_train, y_train)

    # Define model:
    model = Pipeline([
        ('normalizer', Normalizer()),
        ('clf', LinearSVC(
            penalty='l2',
            dual=True,
            tol=0.0001,
            multi_class='ovr',
            fit_intercept=True,
            intercept_scaling=1,
            class_weight=None,
            verbose=0,
            random_state=None,
            max_iter=1000
        )),
    ])

    # Hyperparameters:
    params = {
        # 1. Loss function:
        "clf__loss": ('hinge', 'squared_hinge'),
        # 2. Regularization:
        "clf__C": (0.001, 0.01, 0.1, 1.0, 10.0, 100.0, 1000.0)
    }

    # Make an fbeta_score scoring object
    scorer = make_scorer(accuracy_score)

    # Perform grid search on the classifier using 'scorer' as the scoring method
    grid_searcher = GridSearchCV(
        estimator = model,
        param_grid = params,
        scoring = scorer,
        cv = cv_sets,
        n_jobs = 2,
        verbose = 1
    )

    # Fit the grid search object to the training data and find the optimal parameters
    grid_fitted = grid_searcher.fit(X_train, y_train)

    # Get parameters & scores:
    best_parameters, score, _ = max(grid_fitted.grid_scores_, key=lambda x: x[1])

    print "[Best Parameters]:"
    print best_parameters
    print "[Best Score]:"
    print score

    # Get the estimator
    best_model = grid_fitted.best_estimator_

    # Train on whole dataset:
    best_model.fit(X_train, y_train)
    y_pred = best_model.predict(X_test)

    print classification_report(y_test, y_pred)
