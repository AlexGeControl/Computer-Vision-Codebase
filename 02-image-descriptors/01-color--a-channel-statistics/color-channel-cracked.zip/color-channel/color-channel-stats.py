# File system:
from os import listdir
from os.path import join
# Image processing:
import numpy as np
import cv2
from sklearn.metrics.pairwise import manhattan_distances, euclidean_distances

# Config:
INPUT_DIR = 'dinos'

if __name__ == '__main__':
    image_features = {}

    for image_filename in listdir(INPUT_DIR):
        image_features[image_filename] = np.asarray(
            # RGB color stats:
            cv2.meanStdDev(
                # Raw image:
                cv2.imread(
                    join(INPUT_DIR, image_filename)
                )
            )
        ).flatten()

    print image_features.keys()

    # Image features:
    X = np.concatenate(
        image_features.values()
    ).reshape(
        (len(image_features), -1)
    ).astype(
        np.float
    )

    # Similarity matrix:
    S = euclidean_distances(
        X
    )
    S_normalized = S / S.max()

    print S_normalized
