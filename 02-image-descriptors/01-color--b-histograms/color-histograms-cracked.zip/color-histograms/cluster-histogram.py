## Set up session:
# Persistence:
import pickle
# File system:
from os import listdir
from os.path import isfile, join
# OpenCV:
import numpy as np
import cv2
# Clustering
import random
from sklearn.mixture import GaussianMixture
# Dimensionality reduction and visualization:
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

## Config:
INPUT = 'dataset'
NUM_BINS = 8
IMAGE_FEATURES = 'image-features.pkl'

class LabHistogram(object):
    """ Extract Lab histogram from given image
    """

    def __init__(self, bins):
        self.bins = bins

    def describe(self, image, mask=None):
        # Convert to Lab color space:
        labImage = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        # Color histogram:
        labHist = cv2.calcHist(
            [labImage],
            [0,1,2],
            None,
            [self.bins] * 3,
            [0, 256] * 3
        )
        # Normalized histogram--let L2 norm equals to 1:
        labHistNormalized = np.zeros_like(labHist)
        cv2.normalize(labHist, labHistNormalized)

        return labHistNormalized.flatten()

if __name__ == '__main__':
    # Initialize feature descriptor:
    descriptor = LabHistogram(NUM_BINS)

    # Extract features from images:
    image_filenames = sorted(listdir(INPUT))

    if (
        isfile(IMAGE_FEATURES)
    ):
        # Load from pickle:
        with open(IMAGE_FEATURES, 'rb') as image_features_pkl:
            image_features = pickle.load(image_features_pkl)
    else:
        # Extract features:
        image_features = np.asarray(
            [descriptor.describe(cv2.imread(join(INPUT, filename))) for filename in image_filenames]
        )
        # Dump as pickle:
        with open(IMAGE_FEATURES, 'wb') as image_features_pkl:
            pickle.dump(image_features, image_features_pkl)

    # Cluster images using Gaussian mixture model:
    gmm = GaussianMixture(
        n_components=2,
        covariance_type='full',
        tol=0.001,
        reg_covar=1e-06,
        max_iter=200,
        n_init=1,
        means_init = image_features[
            [random.choice(range(0, 5)), random.choice(range(5, 10))],
            :
        ],
        random_state=42
    ).fit(image_features)
    cluster_labels = gmm.predict(image_features)

    # Reduce dimensionality for visualization:
    pca = PCA(
        n_components = 2
    )
    image_features_reduced = pca.fit_transform(image_features)

    # Visualize:
    fig = plt.figure()
    ax = fig.add_subplot(111)

    colors = ['r', 'b']
    ax.scatter(
        image_features_reduced[:, 0], image_features_reduced[:, 1],
        color = [colors[label] for label in cluster_labels]
    )
    for i, filename in enumerate(image_filenames):
        ax.annotate(
            filename[0] + filename[-6:-4], (image_features_reduced[i, 0], image_features_reduced[i, 1])
        )

    plt.show()
