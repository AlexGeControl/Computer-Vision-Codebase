## Set up session:
# 1. OpenCV:
import numpy as np
import cv2
import mahotas
# 2. Nearest neighbor classification:
from sklearn.metrics.pairwise import pairwise_distances

## Config:
IMAGE_REFERENCE = 'pokemon_red.png'
IMAGE_TO_BE_SEARCHED = 'shapes.png'

if __name__ == '__main__':
    def describe(image):
        # Load image:
        image_grayscale = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )
        # Gaussian blur:
        image_smoothed = cv2.GaussianBlur(
            image_grayscale,
            (13, 13),
            0
        )
        # Binarize:
        image_binary = cv2.threshold(
            image_smoothed,
            64,
            255,
            cv2.THRESH_BINARY
        )[1]

        # Smooth extracted shape:
        # morph_kernel = None
        morph_kernel = np.ones(
            (7, 7),
            np.uint8
        )
        morph_smoothed = cv2.erode(
            cv2.dilate(
                image_binary,
                morph_kernel,
                iterations = 4
            ),
            morph_kernel,
            iterations = 3
        )

        # Extract ROIs and corresponding features:
        contours = cv2.findContours(
            morph_smoothed.copy(),
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )[1]
        features = []

        for _, contour in enumerate(contours):
            canvas = np.zeros_like(morph_smoothed, dtype=np.uint8)
            cv2.drawContours(
                canvas,
                [contour],
                -1,
                255,
                -1
            )
            (x, y, w, h) = cv2.boundingRect(contour)
            ROI = canvas[y:y+h, x:x+w]

            features.append(
                mahotas.features.zernike_moments(
                    ROI,
                    # Use radius only:
                    cv2.minEnclosingCircle(contour)[1],
                    degree = 8
                )
            )

        return (contours, features)

    # Target feature
    (_, reference_features) = describe(cv2.imread(IMAGE_REFERENCE))

    # Candiate features:
    image_to_be_searched = cv2.imread(IMAGE_TO_BE_SEARCHED)
    (contours, candidate_features) = describe(image_to_be_searched)

    # Distance matrix:
    D = pairwise_distances(candidate_features, reference_features)
    closest = np.argmin(D)

    for index, contour in enumerate(contours):
        box = cv2.minAreaRect(contour)
        box = cv2.boxPoints(box).astype(np.int)
        cv2.drawContours(
            image_to_be_searched,
            [box],
            -1,
            (0, 255,0) if index != closest else (0, 0, 255),
            2
        )

    cv2.imshow('Result', image_to_be_searched)
    cv2.waitKey(0)
